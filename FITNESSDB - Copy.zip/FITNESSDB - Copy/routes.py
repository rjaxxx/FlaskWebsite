from flask import Flask, render_template, request
import sqlite3


app = Flask(__name__)


@app.route('/')
def home():
    return render_template('home.html', title='Home')


@app.route('/me')
def me():
    title = 'ME'
    return render_template('me.html', title=title)


@app.route('/all_exercises')
def all_exercises():
    conn = sqlite3.connect('fitness.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM Exercises")
    exercises = cur.fetchall()
    conn.close()
    return render_template('all_exercises.html', title='Exercises', exercises=exercises)


@app.route("/exercise/<int:id>")
def exercise(id):
    conn = sqlite3.connect('fitness.db')
    cur = conn.cursor()
    cur.execute("""
        SELECT e.exercise_id, e.exercise_name, m.muscle_name, i.image_url
        FROM Exercises e
        INNER JOIN Muscles m ON e.muscle_id = m.muscle_id
        LEFT JOIN Images i ON i.image_id = e.exercise_id
        WHERE e.exercise_id = ?
    """, (id,))
    exercise = cur.fetchone()
    print(exercise)
    title = 'Exercises - ' + str(exercise[1])
    conn.close()
    return render_template('exercise.html', title=title, exercise=exercise)


@app.route('/all_muscles')
def all_muscles():
    conn = sqlite3.connect('fitness.db')
    cur = conn.cursor()
    cur.execute("SELECT * FROM Muscles")
    muscles = cur.fetchall()
    conn.close()
    return render_template('all_muscles.html', title='Muscles', muscles=muscles)


@app.route("/muscle/<int:id>")
def muscle_exercises(id):
    conn = sqlite3.connect('fitness.db')
    cur = conn.cursor()
    cur.execute("SELECT muscle_name FROM Muscles WHERE muscle_id = ?", (id,))
    muscle = cur.fetchone()
    cur.execute("SELECT exercise_id, exercise_name FROM Exercises WHERE muscle_id = ?", (id,))
    exercises = cur.fetchall()
    print(muscle[0])
    title = 'Muscles - ' + str(muscle[0])
    conn.close()
    return render_template('muscle_exercises.html', title=title, muscle=muscle, exercises=exercises)


@app.route('/search')
def search():
    query = request.args.get('query', '').strip()
    conn = sqlite3.connect('fitness.db')
    cur = conn.cursor()
    cur.execute("SELECT muscle_id, muscle_name FROM Muscles WHERE muscle_name LIKE ?", ('%' + query + '%',))
    muscles = cur.fetchall()
    cur.execute("SELECT exercise_id, exercise_name FROM Exercises WHERE exercise_name LIKE ?", ('%' + query + '%',))
    exercises = cur.fetchall()
    conn.close()
    return render_template('search_results.html', title='Search Results', query=query, muscles=muscles, exercises=exercises)


if __name__ == '__main__':
    app.run(debug=True, port=5000)
